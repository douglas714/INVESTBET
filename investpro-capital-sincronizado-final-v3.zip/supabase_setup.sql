-- =====================================================
-- SCRIPT DE CONFIGURAÇÃO DO SUPABASE
-- InvestPro Capital - Versão Corrigida
-- =====================================================

-- 1. Criar tabela de perfis dos usuários
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  username TEXT UNIQUE,
  name TEXT,
  email TEXT,
  phone TEXT,
  cpf TEXT,
  balance DECIMAL(10,2) DEFAULT 0.00,
  monthly_profit DECIMAL(5,2) DEFAULT 0.00,
  accumulated_profit DECIMAL(5,2) DEFAULT 0.00,
  is_admin BOOLEAN DEFAULT FALSE,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Habilitar Row Level Security (RLS)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- 3. Políticas de segurança

-- Política para permitir que usuários vejam apenas seus próprios dados
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

-- Política para permitir que usuários atualizem apenas seus próprios dados
CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

-- Política para permitir inserção de novos perfis
CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Política para administradores (opcional - para acesso total via dashboard)
-- Descomente as linhas abaixo se quiser que admins tenham acesso total via RLS
CREATE POLICY "Admins can view all profiles" ON profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Admins can update all profiles" ON profiles
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Admins can delete profiles" ON profiles
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- 4. Função para criar perfil automaticamente após registro
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, name, username)
  VALUES (
    NEW.id, 
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.email),
    COALESCE(NEW.raw_user_meta_data->>'username', NEW.email)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Trigger para executar a função após criação de usuário
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 6. Função para atualizar timestamp de updated_at
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 7. Trigger para atualizar updated_at automaticamente
CREATE TRIGGER handle_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- 8. Inserir usuário administrador padrão (opcional)
-- Descomente e ajuste conforme necessário
INSERT INTO auth.users (
  id,
  email,
  encrypted_password,
  email_confirmed_at,
  created_at,
  updated_at,
  raw_app_meta_data,
  raw_user_meta_data,
  is_super_admin,
  role
) VALUES (
  gen_random_uuid(),
  'admin@investapp.com',
  crypt('admin123', gen_salt('bf')),
  NOW(),
  NOW(),
  NOW(),
  '{"provider": "email", "providers": ["email"]}',
  '{"name": "Administrador", "username": "admin"}',
  false,
  'authenticated'
);

-- 9. Índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_profiles_email ON profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_username ON profiles(username);
CREATE INDEX IF NOT EXISTS idx_profiles_status ON profiles(status);
CREATE INDEX IF NOT EXISTS idx_profiles_is_admin ON profiles(is_admin);
CREATE INDEX IF NOT EXISTS idx_profiles_created_at ON profiles(created_at);

-- 10. Comentários nas colunas para documentação
COMMENT ON TABLE profiles IS 'Perfis dos usuários da plataforma InvestPro Capital';
COMMENT ON COLUMN profiles.id IS 'ID do usuário (referência para auth.users)';
COMMENT ON COLUMN profiles.username IS 'Nome de usuário único';
COMMENT ON COLUMN profiles.name IS 'Nome completo do usuário';
COMMENT ON COLUMN profiles.email IS 'Email do usuário';
COMMENT ON COLUMN profiles.phone IS 'Telefone do usuário';
COMMENT ON COLUMN profiles.cpf IS 'CPF do usuário';
COMMENT ON COLUMN profiles.balance IS 'Saldo disponível para investimento';
COMMENT ON COLUMN profiles.monthly_profit IS 'Percentual de lucro mensal';
COMMENT ON COLUMN profiles.accumulated_profit IS 'Percentual de lucro acumulado';
COMMENT ON COLUMN profiles.is_admin IS 'Indica se o usuário é administrador';
COMMENT ON COLUMN profiles.status IS 'Status do usuário (active, inactive, etc.)';
COMMENT ON COLUMN profiles.created_at IS 'Data de criação do perfil';
COMMENT ON COLUMN profiles.updated_at IS 'Data da última atualização';

-- =====================================================
-- INSTRUÇÕES DE USO:
-- 
-- 1. Copie e cole este script no SQL Editor do Supabase
-- 2. Execute o script completo
-- 3. Verifique se todas as tabelas e funções foram criadas
-- 4. Configure as variáveis de ambiente no seu projeto
-- 5. Teste o registro de um novo usuário
-- 
-- NOTAS IMPORTANTES:
-- - Este script é idempotente (pode ser executado múltiplas vezes)
-- - As políticas RLS garantem segurança dos dados
-- - O trigger cria automaticamente o perfil após registro
-- - Os índices melhoram a performance das consultas
-- =====================================================

